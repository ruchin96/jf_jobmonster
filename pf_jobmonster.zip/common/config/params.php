<?php
return [
    'adminEmail' => 'jobmonster.administrator@gmail.com',
    'supportEmail' => 'jobmonster.cs@gmail.com',
    'user.passwordResetTokenExpire' => 3600,
];
